import browser from 'webextension-polyfill';


export function initFeatureMusicPacks(root){

}
