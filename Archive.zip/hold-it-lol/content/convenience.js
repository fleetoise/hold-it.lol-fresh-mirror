import browser from "webextension-polyfill";
import * as hdom from "../lib/utils/hdom.js";
import * as hdata from "../lib/utils/hdata.js";
import { dummyObject, featureInitialize } from "../lib/utils/hmisc.js";

const displayPlayingMusic = {
  enable: function () {},

  disable: function () {},
};

const autoCloseMenus = {
  _buttons: null,
  _popObserver: null,
  buttonListener: function (event) {
    document.body.click();
  },
  enable: function () {
    this._popObserver = new MutationObserver((mutations, observer) => {
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (
            node instanceof Element &&
            node.classList.contains("MuiPopper-root")
          ) {
            this._buttons = hdom.getPopButtons(node);
            for (const button of this._buttons) {
              button.addEventListener("click", this.buttonListener);
            }
          }
        }
      }
    });

    this._popObserver.observe(document.body, {
      childList: true,
      subtree: true,
    });
  },
  disable: function () {
    if (this._popObserver) {
      this._popObserver.disconnect();
      for (const button of this._buttons) {
        button.removeEventListener("click", this.buttonListener);
      }
    }
  },
};

const activateOnHover = {
  _buttons: null,
  buttonListener: function (event) {
    event.target.click();
    hdom.getInputBox().focus();
  },
  enable: function () {
    this._buttons = document
      .querySelector("[data-testid=PaletteIcon]") // xd
      .parentElement.parentElement.querySelectorAll("button");
    for (const button of this._buttons) {
      button.addEventListener("mouseenter", this.buttonListener);
    }
  },
  disable: function () {
    if (this._buttons) {
      for (const button of this._buttons) {
        button.removeEventListener("mouseenter", this.buttonListener);
      }
    }
  },
};

const autoRecord = {
  enable: function () {
    let menuObserver = new MutationObserver(function (mutations, observer) {
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (node.textContent?.includes("Record")) {
            hdom.elementFromText("MuiMenuItem-root", "Record")[0].click();
            observer.disconnect();
            break;
          }
        }
      }
    });
    document.querySelector(".MuiIconButton-edgeStart").click();
    menuObserver.observe(document.body, {
      childList: true,
      subtree: true,
    });
  },
  disable: () => {},
};

const messageBell = {
  _bellText: "",
  _containsBellText: function (node) {
    if (this._bellText && this._bellText.length > 0) {
      return node.innerText?.substring([node.innerText.indexOf("\n") + 2]).includes(this._bellText);
    }
    return false;
  },
  _observer: null,
  _storageListener: function (changes, area) {
    if (area == "local" && changes.bellText) {
      this._bellText = changes.bellText.newValue || "";
    }
  },
  enable: function () {
    browser.storage.local.get(["bellText"]).then((result) => {
      if (result.bellText) {
        this._bellText = result.bellText || "";
      }
    });

    browser.storage.onChanged.addListener(this._storageListener.bind(this));

    this._observer = hdom.chatMessageObserver((node) => {
      if (
        node instanceof Element &&
        node.classList.contains("MuiListItem-root") &&
        this._containsBellText(node)
      ) {
        browser.runtime.sendMessage({
          type: "hil-notification",
          title: "Holdit.lol Notification",
          message: "Bell text found in courtroom chat log",
        });
      }
    });
  },

  disable: function () {
    if (this._storageListener) {
      browser.storage.onChanged.removeListener(this._storageListener);
    }
    if (this._observer) {
      this._observer.disconnect();
    }
  },
};

const disableTestimonyShortcut = {
  interceptShortcut: function (event) {
    if (document.activeElement != hdom.getInputBox()) {
      event.stopImmediatePropagation();
    }
  },
  enable: function () {
    document.addEventListener("keydown", this.interceptShortcut, true);
  },
  disable: function () {
    document.removeEventListener("keydown", this.interceptShortcut, true);
  },
};

const quickSoundsAndMusic = {
  interceptClick: function (event) {
    if (event.target.closest(".MuiAutocomplete-listbox")) { // MuiPopper-root MuiButtonBase-root
      const parentPopper = [...document.querySelectorAll(".MuiPopper-root")].filter((n) => n.querySelector('button') != null)[0]
      this.hdom.elementFromText("MuiButtonBase-root", "Insert Tag", parentPopper)[0].click();
      document.body.click();
    }
  },
  enable: function () {
    this.hdom = hdom;
    this._interceptClick = this.interceptClick.bind(this);
    document.addEventListener("click", this._interceptClick);
  },
  disable: function () {
    document.removeEventListener("click", this._interceptClick);
  },
};

const features = {
  "auto-record": autoRecord,
  "message-bell": messageBell,
  "unblur-low-res": dummyObject,
  "disable-testimony-shortcut": disableTestimonyShortcut,
  "now-playing": dummyObject,
  "menu-auto-close": autoCloseMenus,
  "menu-hover": activateOnHover,
  "sound-insert": quickSoundsAndMusic,
};


export async function initFeatureConvenience(root, staleOptions) {
  await featureInitialize(features);
}
