import browser from 'webextension-polyfill';


export function initFeatureModeration(root){

}
