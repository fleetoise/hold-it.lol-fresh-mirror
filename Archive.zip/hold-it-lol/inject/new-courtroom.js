'use strict';


function setValue(elem, text) {
  elem.value = text;
  elem.dispatchEvent(new Event('input'));
}


function main(options) {
  console.log(url, auth, title);
}


main();

