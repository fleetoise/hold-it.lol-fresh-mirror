# IMPORTANT

The rewrite is still in development. Any contributions are greatly appreciated.

## hold-it-lol
Quality of life [https://objection.lol/courtroom](objection.lol) courtroom features & tweaks, ranging from tiny UI changes to roleplay testimony UIs.

**Important:** the extension is still in alpha - some assets are unfinished.

## Features
There is a feature timeline tracker at https://holdit-lol-b3e77d.gitlab.io/

## Options

Upon installation, there is a page of options with descriptions to personalize your courtroom experience and pick only the features you like.

It can be accessed by clicking the extension icon in the top right (you may need to pin it in the extensions list).


## Communication

Discord server for development:
https://discord.com/invite/u92NRgSTSy


## How to build the extension
run one of these, depending on the target browser:
```bash
npm run build:firefox
npm run build:chrome
```
